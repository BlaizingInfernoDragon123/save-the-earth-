========================================================================================================================
#(Save The Earth)Notepad file Made In Html,Css and Javascript.
------------------------------------------------------------------------------------------------------------------------
Hello Kedashree Ma'am.
------------------------------------------------------------------------------------------------------------------------
Kindly Plss Read This, 
------------------------------------------------------------------------------------------------------------------------
This Notepad file was Created as  assigned it in the Ms Teams the half yearly 30 marks assignment which 
Due Date is - 6/10/2021. This file was cretaed by Adit Bujar Barua from class="8" sec="E" Roll No="1" School id no="9470"
using html tags respectively assigned in the assignment section of Microsoft Teams.
------------------------------------------------------------------------------------------------------------------------

#File Info.(Html)
========================================================================================================================
This Webpage is a Responsive Web Design (RWD) created by Adit Bujar Barua Class=8 Sec=E Roll No=1 
This file is created using Html,Css And Javascript responsively.
------------------------------------------------------------------------------------------------------------------------

#How To Use It.(Download The Zip From Download Option In Ms Teams)
------------------------------------------------------------------------------------------------------------------------
U Can First Download the zip from Ms teams and then extract it in a folder and then run the "Index.html" using any web-
-browser.
========================================================================================================================
#Disclaimer.(Creation Of This Zip).
========================================================================================================================
This Zip File Was created For Half Yearly 30 Marks Assignemnt as instructed in the assignemnt section of Ms Teams;
(file extension- ".html").    
========================================================================================================================
Thanks for Reading ,

By Adit Bujar Barua class=8 sec=E Id No=9470,

For More Information, or any issues realted to this 
contact me at ="Adit9470@mariasps.onmicrosoft.com" at Microsoft Teams
Thanks,